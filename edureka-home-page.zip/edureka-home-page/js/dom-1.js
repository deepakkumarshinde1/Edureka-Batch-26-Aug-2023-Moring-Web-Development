// DOM ==> DOcument object model
// logical representation of html code in browser
// DOM Tree

// document
// document.getElementById()
// document.getElementsByClassName()
// document.getElementsByTagName()

document.querySelector(); // single element
/*
  h1
  #text
  .text-class
*/
document.querySelectorAll(); // multiple element []
