// js code
/* 
            multi line comment
        */
//    create pop up in javascript
// javascript has in-build functions / class / object
// reserved keyword

// alert("Welcome to javascript"); // call
// block ui functionality

// best way display your result will be using a console
// console.log("Hello");
// console.log(1);
// console.log(2);
// console.log(1, 2, 3, 4, 5, 6, 7, 8, 9);
// console.log(1, "abc");

// store a data -->  variable
// variable --> container to store data
// var let const
// keyword NameOfVariable = value;

// var --> declare same variable again and again in same scope
var studentName = "Deepakkumar";
studentName = "sai";
// var studentName = "Kumar";
// var studentName = "Rahul";
// var studentName = "Neha";

// let --> declare variable only once in same scope
let city = "Nashik";

// const --> declare variable only once in same scope
// const --> once value is assign we won't able to replace again
const country = "India";
// country = "USA";
