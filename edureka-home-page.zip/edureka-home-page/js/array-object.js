// array and jsObject
// array
// array collection of same or different data types
// keys auto gen
// keys or index
// index start with zero
//let number = [10, "a", true, null, function () {}, [1, 2, 3, 4]];
//console.log(number);

let student = ["Deepak", 20, 30, 50];
console.log(student);

//jsObject
// collection of data
// has keys and value
// keys are user defined
// keys are called property

let studentData = {
  name: "Deepak",
  batchNo: 20,
  age: 30,
  mark: 50,
}; // JSON ==> Javascript Object Notation

console.log(studentData.name);
console.log(studentData.batchNo);
console.log(studentData.age);
console.log(studentData.mark);

// studentList
let studentList = [
  {
    name: "Deepak",
    age: 30,
  },
  {
    name: "suraj",
    age: 29,
  },
  {
    name: "vinod",
    age: 31,
  },
]; /// JSON array or Object Array

// studentList[1].age

// add (push)
// read (forEach)
// search (find / filter)
// re-create array (map)
